<div class="footer-section" style="direction: rtl">
    <div class="container">
        <div class="footer-grids">
            <div class="col-md-2 footer-grid">
                <h4>شرکت</h4>
                <ul>
                    <li><a href="products.html">محصولات</a></li>
                    <li><a href="#">همکاری</a></li>
                    <li><a href="#">تیم</a></li>
                </ul>
            </div>
            <div class="col-md-2 footer-grid">
                <h4>خدمات</h4>
                <ul>
                    <li><a href="#">پشتیبانی</a></li>
                    <li><a href="#">پرسش های شما</a></li>
                    <li><a href="#">ضمانت</a></li>
                    <li><a href="contact.html">ارتباط با ما</a></li>
                </ul>
            </div>
            <div class="col-md-2 footer-grid">
                <h4>سفارش و تحویل</h4>
                <ul>
                    <li><a href="#">سفارش کالا</a></li>
                    <li><a href="#">ارسال کالا</a></li>
                </ul>
            </div>
            <div class="col-md-2 footer-grid">
                <h4>حقوقی</h4>
                <ul>
                    <li><a href="#">قوانین</a></li>
                </ul>
            </div>
            <div class="col-md-4 footer-grid1">
                <div class="social-icons">
                    <a href="#"><i class="icon"></i></a>
                    <a href="#"><i class="icon1"></i></a>
                    <a href="#"><i class="icon2"></i></a>
                    <a href="#"><i class="icon3"></i></a>
                    <a href="#"><i class="icon4"></i></a>
                </div>
                <p>کلیه ی حقوق متعلق به ایران اپتیک می باشد</p>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>