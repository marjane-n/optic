<?php
//    include "mats.php";
?>
<!--<script src="./js/main.js" type="text/javascript"></script>-->
<div class="header">
    <div class="header-top">
        <div class="container">
            <div class="top-right">
                <ul>
                    <li class="text"><a href="loginpage.php">ورود</a></li>
<!--                    <li>-->
<!--                        <div class="cart box_1">-->
<!--                            <a href="checkout.html">-->
<!--                                <span class="simpleCart_total"> </span> (<span id="simpleCart_quantity"-->
<!--                                                                               class="simpleCart_quantity"> 0 </span>)-->
<!--                            </a>-->
<!--                            <p><a href="javascript:;" class="simpleCart_empty">سبد خرید</a></p>-->
<!--                            <div class="clearfix"></div>-->
<!--                        </div>-->
<!--                    </li>-->
                </ul>
            </div>
            <div class="top-right" style="float: left;">
                <ul>
                    <li class="text"><a href="contact.html">تماس با ما</a></li>
                    <li class="text"><a href="aboutus.html">درباره ما</a></li>
                </ul>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <div class="header-bottom">
        <div class="container">
            <!--/.content-->
            <div class="content white">
                <nav class="navbar navbar-default" role="navigation">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse"
                                data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <h1 class="navbar-brand"><a href="index.php">ایران اپتیک</a></h1>
                    </div>
                    <!--/.navbar-header-->

<!--                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="direction: ltr">-->
<!--                        <ul class="nav navbar-nav">-->
<!--                            <li><a href="index.php">Home</a></li>-->
<!--                            <li class="dropdown">-->
<!--//                                    foreach ($js as $k => $v) {-->
<!--//                                        echo '<a href="#" class="dropdown-toggle" data-toggle="dropdown">'. $k . '<b class="caret"></b></a>';-->
<!--//                                        echo '<ul class="dropdown-menu multi-column columns-3"><div class="row">';-->
<!--//                                        foreach ($v as $k2 => $v2) {-->
<!--//                                            echo '<div class="col-sm-4"><ul class="multi-column-dropdown">';-->
<!--//                                            echo "<li><a class='list' href='products.php?cat0=$k&cat1=$k2&l=1'>$k2</a></li>";-->
<!--//                                            foreach ($v2 as $k3 => $v3) {-->
<!--//                                                echo "<li><a class='list1' href='products.php?cat0=$k&cat1=$k2&cat2=$k3&l=2'>$k3</a></li>";-->
<!--//                                            }-->
<!--//                                            echo '</ul></div>';-->
<!--//                                        }-->
<!--//                                        echo '</div></ul>';-->
<!--//                                    }-->
<!--</ul>-->
<!--</div>-->
<!--</nav>-->
</div>
<!--<div class="search-box">-->
<!--    <div id="sb-search" class="sb-search">-->
<!--        <form>-->
<!--            <input clas s="sb-search-input" placeholder="جستجو..." type="search" name="search" id="search">-->
<!--            <input class="sb-search-submit" type="submit" value="">-->
<!--            <span class="sb-icon-search"> </span>-->
<!--        </form>-->
<!--    </div>-->
<!--</div>-->

<!-- search-scripts -->
<script src="js/classie.js"></script>
<script src="js/uisearch.js"></script>
<script>
    new UISearch(document.getElementById('sb-search'));
</script>
<!-- //search-scripts -->
<div class="clearfix"></div>
</div>
</div>
</div>